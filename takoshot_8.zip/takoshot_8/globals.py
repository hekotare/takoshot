surface = None
graphics = None

class DebugFlags:
    DISPLAY_PLAYER_POSTURE = True # プレイヤーの姿勢を描画

# フォント
default_font = None
font_8 = None
font_10 = None
font_16 = None
font_20 = None
font_40 = None
font_i20 = None
font_i40 = None
font_i80 = None